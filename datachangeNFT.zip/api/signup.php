<?php
header('Access-Control-Allow-Origin: *');
include 'User.php';
//error_reporting(0);
$users=new User;
$mobile=$_POST['mobile'];
$name=$_POST['name'];
$email=$_POST['email'];
$ac_nft_user_id=$_POST['ac_nft_user_id'];
$data=$users->signup($mobile,$email,$name,$ac_nft_user_id);

echo json_encode($data);
?>