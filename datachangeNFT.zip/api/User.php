<?php
include 'Connection.php'; 
include 'Crypto.php'; 
class User{
	private function chk_regNo(){
		do{
			$regNo=rand(111111,99999999);
			$DB=new Connection;
			$chk=$DB->conn->query("SELECT * FROM detail WHERE user_id='$regNo'");
			//echo "SELECT * FROM detail WHERE regNo='$regNo'";
			 $cnt=$chk->num_rows;
		}while($cnt>0);

		return $regNo;
	}
	public function chek($ac_nft_user_id){
		$DB=new Connection;
		$query=$DB->conn->query("SELECT * FROM dbt_user WHERE user_id='$ac_nft_user_id' AND type='api'");	
		if($query->num_rows>0){
			$ds=$query->fetch_assoc();
			$data=array('status'=>'done','wallet_address'=>$ds['wallet_address'],'wallet_key'=>$ds['wallet_key']);
		}else{
			$data=array('status'=>'error','msg'=>'User Id Not Found');
		}
		return $data;
	}
	public function signup($mobile,$email,$name,$ac_nft_user_id){
		$crypto=new Crypto;
		$DB=new Connection;
		$chech_data=$this->chek($ac_nft_user_id);
		if($chech_data['status']=='error'){
			$wallet_data=$crypto->create_polygon_wallet();
			$wallet_address=$wallet_data['ploywallet'];
			$wallet_key=$wallet_data['polykey'];
			$chain_id=137;
			$type='api';
			$user_id=$ac_nft_user_id;//$this->chk_regNo();
			$ins=$DB->conn->query("INSERT INTO dbt_user(email,user_id,wallet_address,wallet_key,phone,f_name,type)VALUES('$email','$user_id','$wallet_address','$wallet_key','$mobile','$name','$type')");
			//echo "INSERT INTO dbt_user(email,user_id,wallet_address,wallet_key,phone,f_name,type)VALUES('$email','$user_id','$wallet_address','$wallet_key','$mobile','$name','$type')";
			if($ins){
				$data=array('status'=>'done','wallet_address'=>$wallet_address,'wallet_key'=>$wallet_key);
			}else{
				$data=array('status'=>'error','msg'=>'Error While creating a new wallet');
			}	
		}else{
			$data=array('status'=>'error','msg'=>'Already Register');
		}
		return $data;

	}
}


?>