<?php
header('Access-Control-Allow-Origin: *');
include 'User.php';
include "Nft.php";
//error_reporting(0);
$users=new User;
$mobile=$_POST['ac_nft_user_id'];
$datas=$users->chek($mobile);
if($datas['status']=='done'){
	$amount=0.02;
	$sender_wallet=$datas['wallet_address'];
	$crypto=new Crypto;
	$dss=$crypto->send_matic($amount,$sender_wallet);
	if($dss['status']=='error'){
			$data=array('status'=>'error','msg'=>'Minting fees not available');
	}else{
		$private_key=$datas['wallet_key'];
		$nft=new Nft;
		$name=$_POST['name'];
		//$Link_of_the_image=$_POST['file'];

		$targetDir	 = "../ipfs-api/files/";
		$fileName = rand(11111111,99999999).basename($_FILES["file"]["name"]);
		$targetFilePath = $targetDir . $fileName;


		$targetDirs	 = "/ipfs-api/files/";
		$targetFilePaths = $targetDirs . $fileName;

		//$file_uri="https://advantageclub.space/api/test/".$fileName;
		$ul="ipfs-api/files/".$fileName;
		$Db=new Connection;
		$file_uri=$Db->myurl($ul);
		$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
		

		$Transaction_fees=$_POST['Transaction_fees'];
		$Gas_fees=$_POST['Gas_fees'];
		$Platform_fees=$_POST['Platform_fees'];
		$Tradeable=$_POST['Tradeable'];
		$Corporate_Name=$_POST['Corporate_Name'];
		$Corporate_id=$_POST['Corporate_id'];
		$Reward_Value=$_POST['Reward_Value'];
		$Video=$_POST['Video'];
		$Voice_memo=$_POST['Voice_memo'];
		$Message=$_POST['Message'];
		$Type_of_Award=$_POST['Type_of_Award'];
		$Awarded_to=$_POST['Awarded_to'];
		$Awarded_by=$_POST['Awarded_by'];
		$metatag=$_POST['metatag'];
		$description=$_POST['description'];
		$Occasion=$_POST['Occasion'];



		 $allowTypes = array('jpg','png','jpeg','gif','pdf');
		    if(in_array($fileType, $allowTypes)){
		        // Upload file to server
		        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
		        	$upload_img= $nft->upload_file($fileName);
		        	$json_data=array('name'=>$name,'description'=>$description,'Occasion'=>$Occasion,'metatag'=>$metatag,'Awarded_by'=>$Awarded_by,'Awarded_to'=>$Awarded_to,'Type_of_Award'=>$Type_of_Award,'Message'=>$Message,'Voice_memo'=>$Voice_memo,'Video'=>$Video,'Reward_Value'=>$Reward_Value,'Corporate_id'=>$Corporate_id,'Corporate_Name'=>$Corporate_Name,'Tradeable'=>$Tradeable,'Platform_fees'=>$Platform_fees,'Gas_fees'=>$Gas_fees,'Transaction_fees'=>$Transaction_fees,'file_uri'=>$file_uri,'image_base32'=>$upload_img['data']['base32'],'img_CID'=>$upload_img['data']['CID'],'img_url1'=>$upload_img['data']['url1'],'img_url2'=>$upload_img['data']['url2']);
		        	//print_r($upload_img['data']);

		        	$json_filename=$upload_img['data']['CID'].'.json';
		        	$file_Path=$targetDir.$json_filename;
		        	$myfile = fopen($file_Path, "w") or die("Unable to open file!");
					$txt=json_encode($json_data);
					if(fwrite($myfile, $txt)){
					//	echo "done";
					}else{
					//	echo "error";
					}

					fclose($myfile);
		        	$upload_json= $nft->upload_file($json_filename);

		        	//print_r($upload_json);
		        	//echo "<br>";
		        	//echo $upload_json['data']['CID'];
		        	//echo "<br>";
		        	
		        	$nft_data=$nft->mint_my_nft($mobile,$upload_json['data']['CID'],$private_key);
		        	//print_r($nft_data);
		        	//exit();
		        	if($nft_data['status']=='200'){
			        	$blockchain_id_query=$Db->conn->query("SELECT * FROM dbt_blockchain_network WHERE status=1");
			        	$blockchain_id_data=$blockchain_id_query->fetch_assoc();
			        	$owner_wallet=$nft_data['receipt']['events']['MarketItemCreated']['returnValues']['creator'];
			        	$contract_address=$nft_data['receipt']['events']['MarketItemCreated']['address'];
			        	$blockchain_id=$blockchain_id_data['id'];
			        	$json_file_id=$nft_data['receipt']['events']['MarketItemCreated']['returnValues']['uri'];
			        	$token_id=$nft_data['receipt']['events']['MarketItemCreated']['returnValues']['tokenId'];
			        	$trx_hash=$nft_data['receipt']['events'][0]['transactionHash'];;//rand(11111,99999);transactionHash
			        	$is_minted=1;
			        	$token_standard='ERC721';
			        	$file=$targetFilePaths;
			        	$json_file=$json_filename;
			        	$img_url1=$upload_img['data']['url1'];
			        	$img_url2=$upload_img['data']['url2'];
			        	$json_url1=$upload_json['data']['url1'];
			        	$json_url2=$upload_json['data']['url2'];

			        	$ins=$Db->conn->query("INSERT INTO dbt_nfts_store (user_id,name,description,Occasion,metatag,Awarded_by,Awarded_to,Type_of_Award,Message,Voice_memo,Video,Reward_Value,Corporate_id,Corporate_Name,Tradeable,Platform_fees,Gas_fees,Transaction_fees,file_uri,trx_hash,owner_wallet,contract_address,blockchain_id,json_file,token_id,is_minted,token_standard,file,json_file_id,img_url1,img_url2,json_url1,json_url2)VALUES('$mobile','$name','$description','$Occasion','$metatag','$Awarded_by','$Awarded_to','$Type_of_Award','$Message','$Voice_memo','$Video','$Reward_Value','$Corporate_id','$Corporate_Name','$Tradeable','$Platform_fees','$Gas_fees','$Transaction_fees','$file_uri','$trx_hash','$owner_wallet','$contract_address','$blockchain_id','$json_file','$token_id','$is_minted','$token_standard','$file','$json_file_id','$img_url1','$img_url2','$json_url1','$json_url2')");

			        	$data=array('status'=>'done','msg'=>"Data saved..",'trx_hash'=>$trx_hash,'token_id'=>$token_id,'system_id'=>$Db->conn->insert_id);
			        }else{
			        	$data=array('status'=>'error','msg'=>'Error While Creating Nft');	
			        }
		        }else{
		        	$data=array('status'=>'error','msg'=>'Error while Saving image..');
		        }
		    }else{
		    	$data=array('status'=>'error','msg'=>'Invalid file type..');
		    }
		}
	}else{
		$data=array('status'=>'error','msg'=>'User Not Found...');
	}








echo json_encode($data);
?>