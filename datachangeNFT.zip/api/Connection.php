<?php 
class Connection{

   protected $dbhost = 'localhost';
    protected $dbuser = 'advantage_nftbox';
    protected $dbpass = '8ANGBWr*a-[p';
    protected $dbname = 'advantage_nftbox';
    public $conn;

    public function __construct(){
         $this->connect();
      }

    public function connect(){


      $this->conn = new mysqli($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname);

        if ($this->conn->error)
        {
            echo "Failed to connect";
        }
        else
        {
           // echo "connected";
        }
    }

    public function send_email($message,$to_email,$subject){
        $api_key='$2y$10$9EQk2jzidFCh0i7gvJyS7ecq/hbR5bHRMkGNLAGxzpihLELarGyse';
        $sender_email="support@mhadv.space";
        $data=array('sender_email'=>$sender_email,'sender_name'=>'support mhadv','to_email'=>$to_email,'api_key'=>$api_key,'subject'=>$subject,'msg'=>$message);
        $url='https://mailerbox.in/api/send_email';
                $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_POST, 1);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $result = curl_exec($ch);

        curl_close($ch);

        return $result;

    }

    public function myurl($url){
        $r="https://advantageclub.space/".$url;
        return $r;
    }
}