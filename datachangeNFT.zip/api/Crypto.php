<?php 
class Crypto{
	

	public function randomPasswords() {
	    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $pass = array(); //remember to declare $pass as an array
	    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
	    for ($i = 0; $i < 5; $i++) {
	        $n = rand(0, $alphaLength);
	        $pass[] = $alphabet[$n];
	    }
	    return implode($pass); //turn the array into a string
	}

	public function randomPassword(){

	  for($a=0;$a<12;$a++){
	      $rand[]=$this->randomPasswords();
	  }
	  return implode(" ",$rand);
	}

	 public function get_eth_xpub($str){
	    $str=urlencode($str);

		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/ethereum/wallet?mnemonic=$str",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => [
		    "x-api-key: 325def83-88cf-4b3a-b095-89434690e0b5"
		  ],
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		$response=json_decode($response,TRUE);
		return $xpub=$response['xpub'];
		}

	}
	 public function get_eth_wallet($int,$xpub){
	  $curl = curl_init();

	  curl_setopt_array($curl, [
	    CURLOPT_URL => "https://api-eu1.tatum.io/v3/ethereum/address/{$xpub}/{$int}",
	    CURLOPT_RETURNTRANSFER => true,
	    CURLOPT_ENCODING => "",
	    CURLOPT_MAXREDIRS => 10,
	    CURLOPT_TIMEOUT => 30,
	    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	    CURLOPT_CUSTOMREQUEST => "GET",
	    CURLOPT_HTTPHEADER => [
	      "x-api-key: 325def83-88cf-4b3a-b095-89434690e0b5"
	    ],
	  ]);

	  $response = curl_exec($curl);
	  $err = curl_error($curl);

	  curl_close($curl);

	  if ($err) {
	    echo "cURL Error #:" . $err;
	  } else {
	    $response=json_decode($response,TRUE);
	    return $response['address'];
	  }

	}


	 public function get_eth_key($int,$str){
	  $curl = curl_init();

	  curl_setopt_array($curl, [
	    CURLOPT_URL => "https://api-eu1.tatum.io/v3/ethereum/wallet/priv",
	    CURLOPT_RETURNTRANSFER => true,
	    CURLOPT_ENCODING => "",
	    CURLOPT_MAXREDIRS => 10,
	    CURLOPT_TIMEOUT => 30,
	    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	    CURLOPT_CUSTOMREQUEST => "POST",
	    CURLOPT_POSTFIELDS => "{\"index\":$int,\"mnemonic\":\"$str\"}",
	    CURLOPT_HTTPHEADER => [
	      "content-type: application/json",
	      "x-api-key: 325def83-88cf-4b3a-b095-89434690e0b5"
	    ],
	  ]);

	  $response = curl_exec($curl);
	  $err = curl_error($curl);

	  curl_close($curl);

	  if ($err) {
	    echo "cURL Error #:" . $err;
	  } else {
	    //echo $response;
	    $response=json_decode($response,TRUE);
	    return $response['key'];
	  }
	}


	 public function get_bsc_key($int,$str){

		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/bsc/wallet/priv",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => "{\"index\":$int,\"mnemonic\":\"$str\"}",
		  CURLOPT_HTTPHEADER => [
		    "content-type: application/json",
		    "x-api-key: 325def83-88cf-4b3a-b095-89434690e0b5"
		  ],
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		    $response=json_decode($response,TRUE);
		    return $response['key'];
		}
	}



	 public function get_bsc_xpub($str){
	    $str=urlencode($str);

		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/bsc/wallet?mnemonic=$str",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => [
		    "x-api-key: 325def83-88cf-4b3a-b095-89434690e0b5"
		  ],
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		 $response=json_decode($response,TRUE);
		return $xpub=$response['xpub'];
		}
	}


	public function get_bsc_account($int,$xpub){

		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/bsc/address/{$xpub}/{$int}",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => [
		    "x-api-key: 325def83-88cf-4b3a-b095-89434690e0b5"
		  ],
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		   $response=json_decode($response,TRUE);
		    return $response['address'];
		}   

	}

	public function create_bscwallet(){
		date_default_timezone_set("Asia/Calcutta"); 
		$startDate=date("Y-m-d");


	   $bsc_int=0;
	   $bsc_str=$this->randomPassword();
	   $bsc_xpub=$this->get_bsc_xpub($bsc_str);

	   $bsc_wallet=$this->get_bsc_account($bsc_int,$bsc_xpub);
	   

	   $bsc_key=$this->get_bsc_key($bsc_int,$bsc_str);
	   $data=array('bsc_wallet'=>$bsc_wallet,'bsc_key'=>$bsc_key);
	   return $data;
	}

	public function create_wallet(){
			$index=rand(1,9999);
			$xdata=$this->get_tron_menimonic();

		    $wallet= $this->get_tron_wallet($xdata['xpub'],$index);

		    $tronkey= $this->get_tron_key($index,$xdata['mnemonic']);

		    $data=array('tronwallet'=>$wallet,'tronkey'=>$tronkey);

		    return $data;
	}

	public function create_polygon_wallet(){
			$index=rand(1,9999);
			$xdata=$this->get_polygon_menimonic();

		    $wallet= $this->get_polygon_wallet($xdata['xpub'],$index);

		    $tronkey= $this->get_polygon_key($index,$xdata['mnemonic']);

		    $data=array('ploywallet'=>$wallet,'polykey'=>$tronkey);

		    return $data;
	}



	public function get_tron_menimonic(){
		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_HTTPHEADER => [
		    "x-api-key: 325def83-88cf-4b3a-b095-89434690e0b5"
		  ],
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/tron/wallet",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_CUSTOMREQUEST => "GET",
		]);

		$response = curl_exec($curl);
		$error = curl_error($curl);

		curl_close($curl);

		if ($error) {
		  echo "cURL Error #:" . $error;
		} else {
		   $response=json_decode($response,TRUE);
		   return $response;
		}
	}


	public function get_tron_wallet($xpub,$index){
		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_HTTPHEADER => [
		    "x-api-key: 325def83-88cf-4b3a-b095-89434690e0b5"
		  ],
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/tron/address/" . $xpub . "/" . $index,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_CUSTOMREQUEST => "GET",
		]);

		$response = curl_exec($curl);
		$error = curl_error($curl);

		curl_close($curl);

		if ($error) {
		  echo "cURL Error #:" . $error;
		} else {
			$response=json_decode($response,TRUE);
			return $response['address'];
		}
	}
	public function get_tron_key($index,$menimonic){

		$curl = curl_init();

		$payload = array(
		  "index" => $index,
		  "mnemonic" => $menimonic
		);

		curl_setopt_array($curl, [
		  CURLOPT_HTTPHEADER => [
		    "Content-Type: application/json",
		    "x-api-key: 325def83-88cf-4b3a-b095-89434690e0b5"
		  ],
		  CURLOPT_POSTFIELDS => json_encode($payload),
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/tron/wallet/priv",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_CUSTOMREQUEST => "POST",
		]);

		$response = curl_exec($curl);
		$error = curl_error($curl);

		curl_close($curl);

		if ($error) {
		  echo "cURL Error #:" . $error;
		} else {
		  $response=json_decode($response,TRUE);
		  return $response['key'];
		}
	}

	public function  get_token_balance($bsc_wallet,$token){
	  	$curl = curl_init();
		$url="https://api.bscscan.com/api?module=account&action=tokenbalance&contractaddress=".$token."&address=".$bsc_wallet."&tag=latest&apikey=N4Y8AX7GX5CKAPV5VM5KEVWWB3W1YRF51N";

		curl_setopt_array($curl, [
		  CURLOPT_URL => $url,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  /*CURLOPT_HTTPHEADER => [
		    "x-api-key: 9fd7685d-e39d-4fb5-898a-f8b3e8e758f2"
		  ],*/
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		 // echo $response;
		  $response1=json_decode($response,TRUE);
		  if($response1['result']>0){
		  $trc10_amount=$response1['result'];
		 $trc10_amount=$trc10_amount/1000000000000000000;
		//echo doubleval($trc10_amount);
		 $trc10_amount= number_format((float)$trc10_amount, 18, '.', '');
		//exit();

		}else{
		  $trc10_amount=0;
		}
		}

		return $trc10_amount;
	}

	public function send_token($admin_wallet,$wallet_key,$amount,$token){

	    $curl = curl_init();

	    curl_setopt_array($curl, [
	      CURLOPT_URL => "https://api-eu1.tatum.io/v3/blockchain/token/transaction",
	      CURLOPT_RETURNTRANSFER => true,
	      CURLOPT_ENCODING => "",
	      CURLOPT_MAXREDIRS => 10,
	      CURLOPT_TIMEOUT => 30,
	      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	      CURLOPT_CUSTOMREQUEST => "POST",
	      CURLOPT_POSTFIELDS => "{\"chain\":\"BSC\",\"to\":\"$admin_wallet\",\"amount\":\"$amount\",\"contractAddress\":\"$token\",\"digits\":18,\"fromPrivateKey\":\"$wallet_key\"}",
	      CURLOPT_HTTPHEADER => [
	        "content-type: application/json",
	        "x-api-key: 9fd7685d-e39d-4fb5-898a-f8b3e8e758f2",
	      ],
	    ]);

	   echo $response = curl_exec($curl);
	    $err = curl_error($curl);
	    //exit();

	    curl_close($curl);

	    if ($err) {
	      echo "cURL Error #:" . $err;
	    } else {
	       $response=json_decode($response,TRUE);
	       return $response['txId'];
	    }
	}

	public function get_bnb($bsc_wallet){
		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/bsc/account/balance/$bsc_wallet",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "GET",
		  CURLOPT_HTTPHEADER => [
		    "x-api-key: 9fd7685d-e39d-4fb5-898a-f8b3e8e758f2"
		  ],
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		   $response=json_decode($response,TRUE);
		   return $response['balance'];
		}
	}

	public function send_bnb($wallet,$amount,$admin_key){

		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/bsc/transaction",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => "{\"to\":\"$wallet\",\"currency\":\"BSC\",\"amount\":\"$amount\",\"fromPrivateKey\":\"$admin_key\"}",
		  CURLOPT_HTTPHEADER => [
		    "content-type: application/json",
		    "x-api-key: 7871f86e-bb82-4f03-88bd-a4ef77bceee2"
		  ],
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		curl_close($curl);
		    if ($err) {
		      echo "cURL Error #:" . $err;
		    } else {
		       $response=json_decode($response,TRUE);
		       return $response['txId'];
		    }
	}

	public function get_polygon_menimonic(){
		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_HTTPHEADER => [
		    "x-api-key: 7871f86e-bb82-4f03-88bd-a4ef77bceee2"
		  ],
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/polygon/wallet",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_CUSTOMREQUEST => "GET",
		]);

		 $response = curl_exec($curl);
		$error = curl_error($curl);

		curl_close($curl);

		if ($error) {
		  echo "cURL Error #:" . $error;
		} else {
		  	   $response=json_decode($response,TRUE);
		   return $response;
		}
	}

	public function get_polygon_wallet($xpub,$index){
			
		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_HTTPHEADER => [
		    "x-api-key: 7871f86e-bb82-4f03-88bd-a4ef77bceee2"
		  ],
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/polygon/address/" . $xpub . "/" . $index,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_CUSTOMREQUEST => "GET",
		]);

		 $response = curl_exec($curl);
		$error = curl_error($curl);

		curl_close($curl);

		if ($error) {
		  echo "cURL Error #:" . $error;
		} else {
			$response=json_decode($response,TRUE);
			return $response['address'];
		}
	}

	public function get_polygon_key($index,$menimonic){

		$curl = curl_init();

		$payload = array(
		  "index" => $index,
		  "mnemonic" => $menimonic
		);

		curl_setopt_array($curl, [
		  CURLOPT_HTTPHEADER => [
		    "Content-Type: application/json",
		    "x-api-key: 7871f86e-bb82-4f03-88bd-a4ef77bceee2"
		  ],
		  CURLOPT_POSTFIELDS => json_encode($payload),
		  CURLOPT_URL => "https://api-eu1.tatum.io/v3/polygon/wallet/priv",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_CUSTOMREQUEST => "POST",
		]);

		$response = curl_exec($curl);
		$error = curl_error($curl);

		curl_close($curl);

		if ($error) {
		  echo "cURL Error #:" . $error;
		} else {
		  $response=json_decode($response,TRUE);
		  return $response['key'];
		}
	}
	public function ploy_bal($wallet){
		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_HTTPHEADER => [
		    "x-api-key: 7871f86e-bb82-4f03-88bd-a4ef77bceee2"
		  ],
		  CURLOPT_URL => "https://api.tatum.io/v3/polygon/account/balance/".$wallet,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_CUSTOMREQUEST => "GET",
		]);

		$response = curl_exec($curl);
		$error = curl_error($curl);

		curl_close($curl);

		if ($error) {
		  echo "cURL Error #:" . $error;
		} else {
		   $response=json_decode($response,TRUE);
		   return $response['balance'];
		}
	}


	public function poly_nft($wallet){
		$chain='MATIC';
			
		$curl = curl_init();

		curl_setopt_array($curl, [
		  CURLOPT_HTTPHEADER => [
		    "x-api-key: 7871f86e-bb82-4f03-88bd-a4ef77bceee2"
		  ],
		  CURLOPT_URL => "https://api.tatum.io/v3/nft/address/balance/".$chain."/".$wallet,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_CUSTOMREQUEST => "GET",
		]);

		$response = curl_exec($curl);
		$error = curl_error($curl);

		curl_close($curl);

		if ($error) {
		  echo "cURL Error #:" . $error;
		} else {
		   $response=json_decode($response,TRUE);
		   return $response;
		}
	}


	public function send_matics($amount,$wallet){
		$curl = curl_init();

		$payload = array(
		  "to" => $wallet,
		  "currency" => "MATIC",
		  "amount" => $amount,
		  "fromPrivateKey" => "51a368992478ba54433c03fddbb2c293f5754f8df9a2e5e3e92e325de8b8fcb3"
		);

		curl_setopt_array($curl, [
		  CURLOPT_HTTPHEADER => [
		    "Content-Type: application/json",
		    "x-api-key: 7871f86e-bb82-4f03-88bd-a4ef77bceee2"
		  ],
		  CURLOPT_POSTFIELDS => json_encode($payload),
		  CURLOPT_URL => "https://api.tatum.io/v3/polygon/transaction",
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_CUSTOMREQUEST => "POST",
		]);

		echo $response = curl_exec($curl);
		$error = curl_error($curl);

		curl_close($curl);

		if ($error) {
		  echo "cURL Error #:" . $error;
		} else {
		   $response1=2;
		   return $response1;
		}
	}

	public function send_matic($amount,$wallet){
		$mybal=$this->ploy_bal($wallet);
		if($mybal>=$amount){
			$data=['status'=>'done'];
		}else{
			$remain_bal=$amount-$mybal;
			$admin_bal=$this->ploy_bal('0x406fD150F6b0F66453ae6Df39622f4ED09578702');
			if($admin_bal>=$remain_bal){
				$datas=$this->send_matics($remain_bal,$wallet);
				if($datas==2){
					$data=['status'=>'done'];
				}else{
					$data=['status'=>'error','msg'=>'Error While Transferring fee Amount to Wallet'];		
				}
			}else{
				$data=['status'=>'error','msg'=>'Not Enough Amount In Wallet'];
			}
		}
		return $data;
	}

}


?>