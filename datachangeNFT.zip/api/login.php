<?php
header('Access-Control-Allow-Origin: *');
include 'User.php';
//error_reporting(0);
$users=new User;
 $mobile=$_POST['ac_nft_user_id'];
$data=$users->chek($mobile);

echo json_encode($data);
?>