<?php
$myfile = fopen("test/myfile.json", "w") or die("Unable to open file!");
$data=array('status'=>'done','msg'=>"Backend Working in progress");
$txt=json_encode($data);
if(fwrite($myfile, $txt)){
	echo "done";
}else{
	echo "error";
}

fclose($myfile);
?>