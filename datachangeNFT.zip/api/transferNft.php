<?php
header('Access-Control-Allow-Origin: *');
include 'User.php';
include "Nft.php";
//error_reporting(0);
$users=new User;
$sender_id=$_POST['sender_id'];
$reciver_id=$_POST['reciver_id'];
$token_id=$_POST['token_id'];
$Db=new Connection;
$nft=new Nft;
$sender_id_datas=$users->chek($sender_id);
if($sender_id_datas['status']=='done'){
	$reciver_id_datas=$users->chek($reciver_id);
	if($reciver_id_datas['status']=='done'){
		 $sender_privat_key=$sender_id_datas['wallet_key'];
		 $reciver_wallet=$reciver_id_datas['wallet_address'];
		$nft_query=$Db->conn->query("SELECT * FROM dbt_nfts_store WHERE token_id='$token_id' AND user_id='$sender_id'");

		
		if($nft_query->num_rows>0){
			$amount=0.02;
			$sender_wallet=$sender_id_datas['wallet_address'];
			$crypto=new Crypto;
				$dss=$crypto->send_matic($amount,$sender_wallet);
				if($dss['status']=='error'){
					$data=array('status'=>'error','msg'=>'Minting fees not available');
				}else{
					$nft_query_data=$nft_query->fetch_assoc();
					$token_id=$nft_query_data['token_id'];
					$ds=$nft->nft_transfer($token_id,$reciver_wallet,$sender_privat_key);
					//print_r($ds);
					if($ds['status']=='200'){
					$update_query=$Db->conn->query("UPDATE dbt_nfts_store SET user_id='$reciver_id',owner_wallet='$owner_wallet',collection_id='0' WHERE token_id='$token_id'");
					$insert_into_transfer=$Db->conn->query("INSERT INTO transfer_history(sender_id,reciver_id,token_id)VALUES('$sender_id','$reciver_id','$token_id')");
					$data=array('status'=>'done');
					}else{
					$data=array('status'=>'error','msg'=>'NFT transfer failed..');	
				}
		}else{
			$data=array('status'=>'error','msg'=>'NFT Not Found');
		}
		
	}else{
	$data=array('status'=>'error','msg'=>'Reciver Does Not Found...');
	}
}else{
	$data=array('status'=>'error','msg'=>'Sender Not Found...');
}

echo json_encode($data);

?>