<?php
header('Access-Control-Allow-Origin: *');
include 'User.php';
//error_reporting(0);
$users=new User;
$mobile=$_POST['ac_nft_user_id'];
$name=$_POST['name'];
//$Link_of_the_image=$_POST['file'];

$targetDir = "test/";
$fileName = round(11111111,99999999).basename($_FILES["file"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);


$file_uri="https://advantageclub.space/api/".$fileName;



$Transaction_fees=$_POST['Transaction_fees'];
$Gas_fees=$_POST['Gas_fees'];
$Platform_fees=$_POST['Platform_fees'];
$Tradeable=$_POST['Tradeable'];
$Corporate_Name=$_POST['Corporate_Name'];
$Corporate_id=$_POST['Corporate_id'];
$Reward_Value=$_POST['Reward_Value'];
$Video=$_POST['Video'];
$Voice_memo=$_POST['Voice_memo'];
$Message=$_POST['Message'];
$Type_of_Award=$_POST['Type_of_Award'];
$Awarded_to=$_POST['Awarded_to'];
$Awarded_by=$_POST['Awarded_by'];
$metatag=$_POST['metatag'];
$description=$_POST['description'];
$Occasion=$_POST['Occasion'];



 $allowTypes = array('jpg','png','jpeg','gif','pdf');
    if(in_array($fileType, $allowTypes)){
        // Upload file to server
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
        	$Db=new Connection;
        	$ins=$Db->conn->query("INSERT INTO dbt_nfts_store (user_id,name,description,Occasion,metatag,Awarded_by,Awarded_to,Type_of_Award,Message,Voice_memo,Video,Reward_Value,Corporate_id,Corporate_Name,Tradeable,Platform_fees,Gas_fees,Transaction_fees,file_uri)VALUES('$mobile','$name','$description','$Occasion','$metatag','$Awarded_by','$Awarded_to','$Type_of_Award','$Message','$Voice_memo','$Video','$Reward_Value','$Corporate_id','$Corporate_Name','$Tradeable','$Platform_fees','$Gas_fees','$Transaction_fees','$file_uri')");

        	$data=array('status'=>'done','msg'=>"Data saved..");
        }else{
        	$data=array('status'=>'error','msg'=>'Error while Saving image..');
        }
    }else{
    	$data=array('status'=>'error','msg'=>'Invalid file type..');
    }








echo json_encode($data);
?>