<?php
include 'Crypto.php';
$crypto=new Crypto;
$wallet='0x73a82b0b8dbfed4ba13c750b9dc819ca284da39e';
print_r($crypto->poly_nft($wallet));

?>