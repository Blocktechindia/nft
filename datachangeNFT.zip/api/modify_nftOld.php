<?php
header('Access-Control-Allow-Origin: *');
include 'User.php';
//error_reporting(0);
$users=new User;
$mobile=$_POST['ac_nft_user_id'];
$datas=$users->chek($mobile);
if($datas['status']=='done'){


	$name=$_POST['name'];
	//$Link_of_the_image=$_POST['file'];

	$targetDir = "test/";
	$fileName = round(11111111,99999999).basename($_FILES["file"]["name"]);
	$targetFilePath = $targetDir . $fileName;
	$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);


	$file_uri="https://advantageclub.space/api/test/".$fileName;



	$Transaction_fees=$_POST['Transaction_fees'];
	$Gas_fees=$_POST['Gas_fees'];
	$Platform_fees=$_POST['Platform_fees'];
	$Tradeable=$_POST['Tradeable'];
	$Corporate_Name=$_POST['Corporate_Name'];
	$Corporate_id=$_POST['Corporate_id'];
	$Reward_Value=$_POST['Reward_Value'];
	$Video=$_POST['Video'];
	$Voice_memo=$_POST['Voice_memo'];
	$Message=$_POST['Message'];
	$Type_of_Award=$_POST['Type_of_Award'];
	$Awarded_to=$_POST['Awarded_to'];
	$Awarded_by=$_POST['Awarded_by'];
	$metatag=$_POST['metatag'];
	$description=$_POST['description'];
	$Occasion=$_POST['Occasion'];
	$trx_hash=$_POST['trx_hash'];





	 $allowTypes = array('jpg','png','jpeg','gif','pdf');
	    if(in_array($fileType, $allowTypes)){
	        // Upload file to server
	        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
	        	$Db=new Connection;
	        	$ins=$Db->conn->query("UPDATE dbt_nfts_store SET user_id='$mobile',name='$name',description='$description',Occasion='$Occasion',metatag='$metatag',Awarded_by='$Awarded_by',Awarded_to='$Awarded_to',Type_of_Award='$Type_of_Award',Message='$Message',Voice_memo='$Voice_memo',Video='$Video',Reward_Value='$Reward_Value',Corporate_id='$Corporate_id',Corporate_Name='$Corporate_Name',Tradeable='$Tradeable',Platform_fees='$Platform_fees',Gas_fees='$Gas_fees',Transaction_fees='$Transaction_fees',file_uri='$file_uri' WHERE trx_hash='$trx_hash' ");

	        	$data=array('status'=>'done','msg'=>"Data saved..");
	        }else{
	        	$data=array('status'=>'error','msg'=>'Error while Saving image..');
	        }
	    }else{
	    	$data=array('status'=>'error','msg'=>'Invalid file type..');
	    }
	}else{
		$data=array('status'=>'error','msg'=>'User Not Found...');
	}








echo json_encode($data);
?>