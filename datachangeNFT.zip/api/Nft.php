<?php 

class Nft {
	public function connect_polygon($pk){
	    $url = 'http://advantageclub.space:3005/connectPolygonWeb3';
         $data = [
            "pk"=>$pk,
            
        ];
        // Collection object
        // Initializes a new cURL session
        $curl = curl_init($url);
        // Set the CURLOPT_RETURNTRANSFER option to true
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        // Set the CURLOPT_POST option to true for POST request
        curl_setopt($curl, CURLOPT_POST, true);
               curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
        // Set the request data as JSON using json_encode function
       // curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
        // Set custom headers for RapidAPI Auth and Content-Type header
        // rzp_test_UTOvzw94xuaTe1:hGlY0QmhvVxXMpj8fezfcaCg
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
             'Accept: */*',
  'Authorization:Basic YWRtaW46YWRtaW5AMTIz',
             'Content-Type: application/json'
        ]);
        // Execute cURL request with all previous settings
           $response = curl_exec($curl);
        // Close cURL session
        curl_close($curl);
        $response1=json_decode($response,TRUE);
        return  $response1;
	}
	public function connect_Contract(){
         $url = 'http://advantageclub.space:3005/initACNFTContract';
        
        // Initializes a new cURL session
        $curl = curl_init($url);
        // Set the CURLOPT_RETURNTRANSFER option to true
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        // Set the CURLOPT_POST option to true for POST request
        curl_setopt($curl, CURLOPT_POST, true);
        // Set the request data as JSON using json_encode function
       // curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
        // Set custom headers for RapidAPI Auth and Content-Type header
        // rzp_test_UTOvzw94xuaTe1:hGlY0QmhvVxXMpj8fezfcaCg
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
             'Accept: */*',
             'Authorization:Basic YWRtaW46YWRtaW5AMTIz',
             'Content-Type: application/json'
        ]);
        // Execute cURL request with all previous settings
          $response = curl_exec($curl);
        // Close cURL session
        curl_close($curl);
        $response1=json_decode($response,TRUE);

        return  $response1;

        
	}

     public function mint_nft($urls,$private_key){
          $urls=urlencode($urls);
          $url = "advantageclub.space:3005/mintNFT?url=$urls";
        // Collection object
        $data = [
            "url"=> $url,
        ];
        // Initializes a new cURL session
        $curl = curl_init($url);
        // Set the CURLOPT_RETURNTRANSFER option to true
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        // Set the CURLOPT_POST option to true for POST request
        curl_setopt($curl, CURLOPT_POST, true);
        // Set the request data as JSON using json_encode function
       //curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
        // Set custom headers for RapidAPI Auth and Content-Type header
        // rzp_test_UTOvzw94xuaTe1:hGlY0QmhvVxXMpj8fezfcaCg
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
             'Accept: */*',
  'Authorization:Basic YWRtaW46YWRtaW5AMTIz',
             'Content-Type: application/json'
        ]);
        // Execute cURL request with all previous settings
         $response = curl_exec($curl);
        // Close cURL session
        curl_close($curl);
        $response1=json_decode($response,TRUE);

        return  $response1;
     }

	public function mint_my_nft($ac_nft_user_id,$url,$private_key){
          $this->connect_polygon($private_key);
          $this->connect_Contract();
          $data=$this->mint_nft($url,$private_key);
          if($data['receipt']['status']==1){
               $ds['status']='done';
               $ds['token_id']=$data['receipt']['events']['MarketItemCreated']['returnValues']['tokenId'];
               $ds['price']=0;//$data['receipt']['events']['MarketItemCreated']['returnValues']['tokenId'];
               $ds['is_minted']=1;
               $ds['trx_hash']=$data['receipt']['events']['MarketItemCreated']['transactionHash'];
               $ds['file_uri']=$data['receipt']['events']['MarketItemCreated']['returnValues']['uri'];
               $ds['creator']=$data['receipt']['events']['MarketItemCreated']['returnValues']['creator'];
               $ds['forSale']=$data['receipt']['events']['MarketItemCreated']['returnValues']['forSale'];
               
          }
         // print_r($data);
          return $data;
	}




     public function nft_transfer($token_id,$reciver_address,$private_key){
            $this->connect_polygon($private_key);
          $this->connect_Contract();
          $url = "http://advantageclub.space:3005/transferNFT";
        // Collection object
        $data = [
            "receiverAddress"=>$reciver_address,
            "tokenId" =>$token_id,
            "fees" => '0.0001',
        ];
        //echo json_encode($data)."<br>";
        // Initializes a new cURL session
        $curl = curl_init($url);
        // Set the CURLOPT_RETURNTRANSFER option to true
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        // Set the CURLOPT_POST option to true for POST request
        curl_setopt($curl, CURLOPT_POST, true);
        // Set the request data as JSON using json_encode function
       curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
        // Set custom headers for RapidAPI Auth and Content-Type header
        // rzp_test_UTOvzw94xuaTe1:hGlY0QmhvVxXMpj8fezfcaCg
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
             'Accept: */*',
             'Authorization:Basic YWRtaW46YWRtaW5AMTIz',
             'Content-Type: application/json'
        ]);
        // Execute cURL request with all previous settings
         $response = curl_exec($curl);
        // Close cURL session
        curl_close($curl);
        $response1=json_decode($response,TRUE);
        return $response1;
       // print_r($response1);


     }


     public function upload_file($file){
        $url = "advantageclub.space:3001/uploadFile";
        // Collection object
        $data = [
            "path" => './files/'.$file
        ];
         //json_encode($data)."<br>";
        // Initializes a new cURL session
        $curl = curl_init($url);
        // Set the CURLOPT_RETURNTRANSFER option to true
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        // Set the CURLOPT_POST option to true for POST request
        curl_setopt($curl, CURLOPT_POST, true);
        // Set the request data as JSON using json_encode function
       curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
        // Set custom headers for RapidAPI Auth and Content-Type header
        // rzp_test_UTOvzw94xuaTe1:hGlY0QmhvVxXMpj8fezfcaCg
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
             'Accept: */*',
             'Content-Type: application/json'
        ]);
        // Execute cURL request with all previous settings
         $response = curl_exec($curl);
        // Close cURL session
        curl_close($curl);
        $response1=json_decode($response,TRUE);

       // print_r($response1);
        return $response1;
     }  
     public function update_nft($token_id,$private_key,$urls){
          $this->connect_polygon($private_key);
          $this->connect_Contract();
          $url = "advantageclub.space:3005/updateTokenURI";
        $data = [
            "tokenId" => $token_id,
            "uri"=> $urls
        ];
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
        curl_setopt($curl, CURLOPT_HTTPHEADER, [
             'Accept: */*',
             'Authorization:Basic YWRtaW46YWRtaW5AMTIz',
             'Content-Type: application/json'
        ]);
         $response = curl_exec($curl);
        curl_close($curl);
        $response1=json_decode($response,TRUE);
        return $response1;
     }  

}




?>

