<?php
header('Access-Control-Allow-Origin: *');
include 'User.php';
//error_reporting(0);
$users=new User;
 $mobile=$_POST['ac_nft_user_id'];
$datas=$users->chek($mobile);
if($datas['status']=='done'){
	$Db=new Connection;
	$query=$Db->conn->query("SELECT * FROM dbt_nfts_store WHERE user_id='$mobile'");
	if($query->num_rows>0){
		while($ds=$query->fetch_assoc()){
			$dt[]=$ds;
		}
		$data=array('status'=>'done','data'=>$dt);
	}else{
		$data=array('status'=>'error','msg'=>"No Record Found");
	}
}else{
	$data=$datas;
}
echo json_encode($data);
?>