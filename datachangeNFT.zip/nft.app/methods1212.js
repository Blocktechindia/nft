
const CONSTANT = require('./constant')
const Web3 = require('web3');
const contract_abi = require('./ABI/abi.json')
const acnft_abi = require('./ABI/acnft.json');
const PrivateKeyProvider = require("truffle-privatekey-provider");
var contract;
var web3;






module.exports.connectWeb3 = async () => {
    let provider = new PrivateKeyProvider(CONSTANT.from_account_private_key, CONSTANT.bsc_testnet_url);
    web3 = new Web3(provider);
   // console.log(provider);

    // const accounts = await web3.eth.getAccounts();
    // const myWalletAddress = accounts[0];
    // console.log('mywalletaddress ', myWalletAddress);
    return 'web3 connected to testnet';
}

const abi = [
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "userId",
				"type": "string"
			},
			{
				"internalType": "address",
				"name": "add",
				"type": "address"
			}
		],
		"name": "setUser",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "userId",
				"type": "string"
			}
		],
		"name": "getUser",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			},
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "owner",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
]
module.exports.initContract = async () => {
    // await this.connectWeb3();
    console.log(JSON.parse(contract_abi.result))
    contract = await new web3.eth.Contract(JSON.parse(contract_abi.result), CONSTANT.contract_address);
    return contract;
}//https://polygontestapi.terminet.io/rpc
module.exports.connectPolygonWeb3 = async () => {
    let provider = new PrivateKeyProvider('b62088d3c54f76f914d7fe5f0262b30ac28328728afec67dc99d394f87bc6b12','https://rpc-mumbai.maticvigil.com');
    web3 = new Web3(provider);
    return 'web3 connected to testnet';
}//b62088d3c54f76f914d7fe5f0262b30ac28328728afec67dc99d394f87bc6b12
module.exports.initACNFTContract = async () => {
    // await this.connectWeb3();
   // console.log(JSON.parse(contract_abi.result))
    contract = await new web3.eth.Contract(acnft_abi, '0xfcE8c60926111Ec5a369f7050A072B2D966EFeF6');
	console.log('contract',contract);  
  return contract;
}
module.exports.mintNFT = async(res,url) =>{
	const accounts = await web3.eth.getAccounts();
    const myWalletAddress = accounts[0];
     console.log(myWalletAddress);    
    await contract.methods.mintNFT(url).send({from: myWalletAddress, chainId:80001})
	.on('receipt', function (receipt) {
		 console.log('trx receipt', JSON.stringify(receipt));
		res.send({ status: 200,  receipt});
		
	 });
}

module.exports.updateTokenURI = async(tokenId,uri,res) =>{
	const accounts = await web3.eth.getAccounts();
    const myWalletAddress = accounts[0];
    
    await contract.methods.updateTokenURI(tokenId,uri).send({from: myWalletAddress, chainId:80001})
	.on('receipt', function (receipt) {
		 console.log('trx receipt', JSON.stringify(receipt));
		res.send({ status: 200,  receipt});
		
	 });
}


module.exports.transferNFT = async(res,receiverAddress,tokenId,fees) =>{
	const accounts = await web3.eth.getAccounts();
    const myWalletAddress = accounts[0];
    await contract.methods.transferNFT(receiverAddress,tokenId,await web3.utils.toWei(fees.toString(), 'ether')).send({from: myWalletAddress, chainId:80001,
        value:await  web3.utils.toWei(fees.toString(), 'ether')})
	.on('receipt', function (receipt) {
		 console.log('trx receipt', receipt);
		res.send({ status: 200,  receipt});
		
	 });
}

module.exports.createUser = async(userId,address,res,addressData)=>{
    const accounts = await web3.eth.getAccounts();
    const myWalletAddress = accounts[0];
    console.log('mywalletaddress ', myWalletAddress);

    await contract.methods.setUser(userId,address).send({from: myWalletAddress})
        .on('receipt', function (receipt) {
           // console.log('trx receipt', JSON.stringify(receipt));
           res.send({ status: 200,  addressinfo:addressData,data:receipt});
           // return JSON.parse(receipt);
        });
   // return myWalletAddress;
}

module.exports.getUser = async(userId)=>{
    console.log(userId)
   const result =  await contract.methods.getUser(userId).call();
   console.log(result);
    //.on('receipt', function (receipt) {
    //     console.log('trx receipt', receipt);
    //     return receipt;
    // });
    return result;
}

module.exports.getNFTDetail = async(userID)=>{
    
   const result =  await contract.methods.nftmapping(userID).call();
   console.log(result);
    return result;
}


module.exports.createNFT = async(userId,tokenURI,name)=>{
    const accounts = await web3.eth.getAccounts();
    const myWalletAddress = accounts[0];
    console.log('mywalletaddress ', myWalletAddress);
    await contract.methods.mint(tokenURI).send({from: myWalletAddress})
    .on('receipt', function (tokenID) {
         contract.methods.setNFTInfo(userId,name,tokenURI,tokenID).send({from: myWalletAddress})
        .on('receipt', function (response) {
          
           res.send({ status: 200, data:response});
          
        });
    });
    
}


module.exports.sendBNB = async(amount,address)=>{
    const accounts = await web3.eth.getAccounts();
    const myWalletAddress = accounts[0];
    console.log('mywalletaddress ', myWalletAddress);

  var result = await web3.eth.sendTransaction({
        from: myWalletAddress,
        to: address,
        value:await  web3.utils.toWei(amount.toString(), 'ether'),
      }).on('receipt', function (receipt) {
        console.log('trx receipt', receipt);
        return receipt;
    });
    return result;

}

module.exports.getTokenBalance = async (address) => {
    
    return await contract.methods.balanceOf(address).call();
}

// console.log(1500*10**5)
module.exports.transferToken = async (amount,address) => {
    const accounts = await web3.eth.getAccounts();
    const myWalletAddress = accounts[0];
    console.log('mywalletaddress ', myWalletAddress);
    var response = await contract.methods.transfer(address, convertToWei(amount)).send({ from: myWalletAddress })
        .on('receipt', function (receipt) {
            console.log('trx receipt', receipt);
            return receipt;
        });
        return response;

   
}

// module.exports.getBnbBalance = async ()=>{
//   var bal =  await web3.eth.getBalance(req.body.address).then(console.log);

// }

function convertToWei(number) {
    return web3.utils.toWei(number, 'ether');
}
