const express = require('express');
const port = process.env.PORT || 3005;

const Web3 = require('web3');
const bodyParser = require('body-parser');
const nodeEth = require('node-eth-address');
// mainnet
//const web3 = new Web3('https://bsc-dataseed1.binance.org:443');

// testnet
const web3 = new Web3('https://data-seed-prebsc-1-s1.binance.org:8545');
const PrivateKeyProvider = require("truffle-privatekey-provider");
const methods = require('./methods');
const constants = require('./constant');


const app = express();
app.use(bodyParser.json());
const basicAuth = require('express-basic-auth');
const { response } = require('express');

app.use(basicAuth({
    users: { 'admin': 'admin@123' }
}))
app.get('/', async (req, res) => {

    res.send({ status: 200, data: req.body.url});
    
})
  






app.post('/initContract',async(req,res)=>{
    methods.initContract().then(resp=>{
    res.send({ status: 200, data: resp});
}).catch(err => {
    console.error(err);
    res.send({ status: 200, data:   'Contract initiated..' })

})
})

app.post('/initACNFTContract',async(req,res)=>{
    methods.initACNFTContract().then(resp=>{
    res.send({ status: 200, data: resp});
}).catch(err => {
    console.error(err);
    res.send({ status: 200, data:   'Contract initiated..' })

})
})

app.post('/connectPolygonWeb3', async (req, res) => {
    methods.connectPolygonWeb3(req.body.pk).then(response =>{
        res.send({ status: 200, data: response});
    }).catch(err => {
        console.error(err);
        res.send({ status: 411, data: err  +',    please check the web3 connection' })
    })
})
app.post('/mintNFT', async (req, res) => {
    methods.mintNFT(res,req.query.url).then(response =>{
       // res.send({ status: 200, data: response});
    }).catch(err => {
        console.error(err);
        res.send({ status: 411, data: err  +',    please check the web3 connection' })
    })
})
app.post('/updateTokenURI', async (req, res) => {
    methods.updateTokenURI(req.body.tokenId,req.body.uri,res).then(response =>{
       // res.send({ status: 200, data: response});
    }).catch(err => {
        console.error(err);
        res.send({ status: 411, data: err  +',    please check the web3 connection' })
    })
})


app.post('/transferNFT', async (req, res) => {
    methods.transferNFT(res,req.body.receiverAddress,req.body.tokenId,req.body.fees).then(response =>{
       // res.send({ status: 200, data: response});
    }).catch(err => {
        console.error(err);
        res.send({ status: 411, data: err  +',    please check the web3 connection' })
    })
})
app.post('/connectWeb3', async (req, res) => {
    methods.connectWeb3().then(response =>{
        //methods.initContract().then(resp=>{
        //     res.send({ status: 200, data: resp});
        // }).catch(err => {
        //     console.error(err);
        //     res.send({ status: 411, data: err  +',    please check the web3 connection' })
        // })
        res.send({ status: 200, data: response});
    }).catch(err => {
        console.error(err);
        res.send({ status: 411, data: err  +',    please check the web3 connection' })
    })
})
app.post('/createUser',async(req,res)=>{

        let userId = req.query.userId;
        console.log(userId);
        // here save the userID in to the conract, and address generated, map the uniqu userId to address, 
        let addressData =  nodeEth.getDefaultAddress("");
        
        methods.createUser(userId,addressData.address,res,addressData).then(response=>{
            console.log(response)
           // res.send({ status: 200,  data:response});
        }).catch(err => {
            console.error(err);
            res.send({ status: 411, data: err  +',    please check the web3 connection' })
        })

       // res.send({ status: 200, data: {"address":addressData.address}}) 
    
})
app.post('/createNFT',async(req,res)=>{
 let userId = req.query.userId;
 let name = req.query.name;
 let tokenURI = req.query.tokenURI;

 methods.createNFT(userId,tokenURI,name).then(response=>{
    res.send({ status: 200, userId: response[0],address:response[1]});
}).catch(err => {
    console.error(err);
    res.send({ status: 411, data: err  +',    please check the web3 connection' })
})

})
app.post('/getUser',async(req,res)=>{
    let userId = req.query.userId;
    methods.getUser(userId).then(response=>{
        res.send({ status: 200, userId: response[0],address:response[1]});
    }).catch(err => {
        console.error(err);
        res.send({ status: 411, data: err  +',    please check the web3 connection' })
    })
    
})
app.post('/getNFTDetail',async(req,res)=>{
    let userId = req.query.userId;
    methods.getNFTDetail(userId).then(response=>{
        res.send({ status: 200, userId: response[0]});
    }).catch(err => {
        console.error(err);
        res.send({ status: 411, data: err  +',    please check the web3 connection' })
    })
    
})


app.listen(port, () => {
    console.log("Running on port" + port);
  });




