module.exports = {

    from_account_private_key:"b62088d3c54f76f914d7fe5f0262b30ac28328728afec67dc99d394f87bc6b12",//"979e5912591d349c923b579c43a843c32d5db0d2e1a71d984ab7cc51dfeece14",
    bsc_testnet_url:"https://data-seed-prebsc-1-s1.binance.org:8545",
    contract_address:"0xe8aC5Bc4Df902b16f41D40766969145561E12629"//"0x9c2E5EA287E2BfdB11D21A6808Ccdb09ccfd0630" // replace your contract address here...
    
    }