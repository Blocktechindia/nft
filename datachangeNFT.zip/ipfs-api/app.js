import {create} from 'ipfs-http-client';
import express from 'express';
import bodyParser from 'body-parser';
import fs from "fs";

const app = express();
app.use(bodyParser.json());
const projectId = '2HsxTjEMrHfACdkAulWMTId3x7d';
const projectSecret = 'b30b6ad50e90c2341fe8b277d34468ec';
const auth =
    'Basic ' + Buffer.from(projectId + ':' + projectSecret).toString('base64');

async function ipfsClient() {
    const ipfs = await create(
        {
            host: "ipfs.infura.io",
            port: 5001,
            protocol: "https",
            headers: {
                authorization: auth,
            },
        }
    );
    return ipfs;
}


async function saveText() {
    let ipfs = await ipfsClient();

    let result = await ipfs.add(`welcome ${new Date()}`);
    console.log(result);
}
// saveText();
// module.exports.uploadToIPFS = async(path,res)=>{
 async function saveFile(path,res) {

    let ipfs = await ipfsClient();

    let data = fs.readFileSync(path)
    let options = {
        warpWithDirectory: false,
        progress: (prog) => console.log(`Saved :${prog}`)
    }
    let result = await ipfs.add(data, options);
    let v1CID = result.cid.toV1();
    // res.send({ status: 200, data:result,fileUrl:v1CID});
    const url1 = "https://"+v1CID+".ipfs.dweb.link/";
    const url2 = "https://cloudflare-ipfs.com/ipfs/"+v1CID;
    console.log(v1CID);
    console.log(result);
    console.log(url1);
    console.log(url2);
    res.send({ status: 200, data: {base32:v1CID.toString(),CID:result.path,size:result.size,url1:url1,url2:url2}});
}

app.post('/uploadFile',async(req,res)=>{
    saveFile(req.body.path,res);
})
//  saveFile()
app.post('/getData',async(req,res)=>{
    getData(req.body.hash,res);
})

async function getData(hash,res) {
    let ipfs = await ipfsClient();

    let asyncitr = ipfs.cat(hash)

    for await (const itr of asyncitr) {

        let data = Buffer.from(itr).toString("utf8")
        console.log(data)
        res.send({status:200,data:JSON.stringify(data)})
    }
}


 //getData("QmXni7U5fuHNPjyWLYHfZsRZb2wDzCeS46j7WMnSYr5oo2")

 const port = process.env.PORT || 3001;
 app.listen(port, () => {
    console.log("Running on port" + 3001);
  });
